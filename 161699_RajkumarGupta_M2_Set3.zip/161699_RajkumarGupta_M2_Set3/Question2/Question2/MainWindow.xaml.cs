﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Question2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Display_Click(object sender, RoutedEventArgs e)
        {


            Sep19CHNEntities contextObj = new Sep19CHNEntities();


            var query = from Owner own in contextObj.Owners
                        where own.Ramount > 20000       //Query for display Rent Amount greater than 20000
                        select own;


            if (txt_Rent.Text != string.Empty)
            {

                List<Owner> eList = new List<Question2.Owner>();
                eList = query.ToList<Owner>();

                if (eList.Count <= 0)
                {
                    MessageBox.Show("No records Found");
                }
                else
                {
                    dataGrid.ItemsSource = query.ToList();
                }
            }



            else MessageBox.Show("Please enter correct rent amount");

        }
    }
}
