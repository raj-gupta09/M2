use Sep19CHN
create table RajkumarG.Owner -- Create Table
(
FlatId int identity(1000,1) primary key,
Own_Fname varchar(20),
Own_Lname varchar(20),
oMob bigint,
Ftype int,
Farea int,
Ramount int,
Damount int
)




create proc RajkumarG.usp_AddOwner	--Add Owner Procedure
@Own_Fname varchar(20),
@Own_Lname varchar(20),
@oPh bigint,
@Ftype int,
@Farea int,
@Ramount int,
@Damount int
AS
BEGIN
insert into RajkumarG.Owner values(@Own_Fname,@Own_Lname ,@oPh ,@Ftype ,@Farea, @Ramount, @Damount )
END


select * from RajkumarG.Owner